═══════════════════════════════════════════════════════════
  GEMMA-CISO FORENSIC WORKSTATION — TEST EVIDENCE PACK
  Version 1.0 | Prepared for: Vraj Upadhyay
═══════════════════════════════════════════════════════════

This ZIP contains SYNTHETIC test evidence for all 4 domains.
All data is FICTIONAL. Created for tool validation only.

───────────────────────────────────────────────────────────
SCENARIO OVERVIEW
───────────────────────────────────────────────────────────
These 4 files all describe the SAME fictional incident from
different angles — a breach at "MedConnect India Pvt. Ltd."

A credential stuffing attack → database exfiltration →
malware deployment → lateral movement across 4 servers.

Use each file in its matching domain for the richest output.

───────────────────────────────────────────────────────────
FILE → DOMAIN MAPPING
───────────────────────────────────────────────────────────

1. logs/waf_access.log  →  🔍 LOG ANALYST
   Apache/WAF access log containing:
   - Brute force login (10.0.0.5, 8 failed attempts → success)
   - SQL Injection attempts (UNION SELECT, OR 1=1, DROP TABLE)
   - XSS payloads (script tag, onerror cookie steal)
   - Path traversal (/etc/passwd, /etc/shadow)
   - Webshell upload + RCE (shell.php?cmd=whoami)
   - Bulk data export event

2. malware/svchost32.ps1  →  🦠 MALWARE ANALYST
   Malicious PowerShell dropper/RAT containing:
   - Registry persistence (Run key)
   - Sandbox evasion (uptime check, process list scan)
   - C2 beaconing to 185.220.101.47:8080
   - Credential harvesting (Chrome passwords, Credential Manager)
   - Keylogger via Win32 API
   - Lateral movement via SMB + WMI
   - Process injection stub (shellcode loader)

3. legal/breach_report.txt  →  ⚖️ LEGAL ASSISTANT
   Internal incident report containing:
   - 87,450 patient health records exposed
   - HIV status, Aadhaar numbers, prescriptions in scope
   - Discovery timestamp, attacker timeline
   - MFA gap as root cause
   - Ideal for DPDP Act + GDPR + CERT-In deadline analysis

4. ir/siem_alerts.txt  →  🚨 IR HANDLER
   SIEM export (Splunk) + CrowdStrike telemetry containing:
   - 9 CRITICAL/HIGH alerts across 3-hour window
   - 4 confirmed compromised hosts
   - Lateral movement evidence (SMB to 3 servers)
   - Unauthorized admin account creation
   - Scheduled task persistence
   - LSASS memory dump attempt
   - Backup server vssadmin attack (blocked)

BONUS:
   ir/call_detail_records.csv  →  🚨 IR HANDLER or 🔍 LOG ANALYST
   CDR data showing suspicious calling patterns:
   - Unusual international calls to UK/Germany numbers
   - Tower location jumps (Ahmedabad → Mumbai in 5 min)
   - High-frequency short calls before a long-duration call
   - IMEI change detected mid-day (SIM swap indicator)

───────────────────────────────────────────────────────────
HOW TO USE
───────────────────────────────────────────────────────────
Option A: Upload THIS ZIP directly to any domain.
  The tool will auto-extract and analyze all contents.

Option B: Extract and upload individual files to their
  matching domain for the most focused analysis.

Expected analysis time per phase: 15–45 seconds (E2B model)
